#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main() {
    int row,col;
    scanf("%d%d",&row,&col);
    //存储数据的区域
    int *p = (int *)malloc(row*col* sizeof(int));
    //索引数组
    int **pArr = (int **)malloc(row* sizeof(int *));
    for (int i = 0; i < row; ++i) {
        pArr[i] = p+i*col;
    }
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            pArr[i][j] = 0;
        }
    }
}
