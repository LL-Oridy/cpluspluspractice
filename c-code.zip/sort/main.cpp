#include "sort.h"

int main() {
    //随机数种子
    srand((unsigned int) time(NULL));
    int *arr = (int *) malloc(N * sizeof(int));
    for (int i = 0; i < N; ++i) {
        arr[i] = rand() % M;
    }
    int *tmp = (int *) malloc(N * sizeof(int));
    print(arr);
    printf("\n");
    countSort(arr);
    //mergeSort(arr,tmp,0,N-1);
    //heapSort(arr);
    //quickSort(arr,0,N);
    //qsort(arr, N, sizeof(int), compare);
    print(arr);
}

void selectSort(int *arr) {
    //最小值要放置的位置下标从0~N-2
    for (int i = 0; i < N - 1; ++i) {
        int min = i;
        for (int j = i + 1; j < N; ++j) {
            if (arr[min] > arr[j]) {
                min = j;
            }
        }
        SWAP(arr[i], arr[min]);
    }
}

void insertSort(int *arr) {
    //来牌下标
    for (int i = 1; i <= N - 1; ++i) {
        //保存来牌
        int insertVal = arr[i];
        //手牌下标
        int j;
        //把比i大的都后移，从最后面开始挪动
        for (j = i - 1; j >= 0 && arr[j] > insertVal; --j) {
            //往后移
            arr[j + 1] = arr[j];
        }
        arr[j + 1] = insertVal;
    }
}

void shellSort(int *arr) {
    for (int gap = N / 2; gap >= 1; gap >>= 1) {
        //i来牌
        for (int i = gap; i < N; ++i) {
            int insertVal = arr[i];
            int j;
            for (j = i - gap; j >= 0 && arr[j] > insertVal; j -= gap) {
                arr[j + gap] = arr[j];
            }
            arr[j + gap] = insertVal;
        }

    }
}

void quickSort(int *arr, int left, int right) {
    if (left < right) {
        int pivot = partition(arr, left, right);
        quickSort(arr, left, pivot - 1);
        quickSort(arr, pivot + 1, right);
    }
}

int partition(int *arr, int left, int right) {
    int i, j;
    for (i = left, j = left; i < right; ++i) {
        if (arr[i] < arr[right]) {
            SWAP(arr[i], arr[j]);
            ++j;
        }
    }
    SWAP(arr[j], arr[right]);
    return j;
}

int compare(const void *lhs, const void *rhs) {
    int *lp = (int *) lhs;
    int *rp = (int *) rhs;
    //升序排序
    return *lp - *rp;
}

void adjustMaxHeap(int *arr, int pos, int len) {
    //pos->父亲节点的下标，len是堆的规模，每确定一个最大值，堆规模--
    //左孩子：2*pos+1
    int father = pos;
    int son = 2 * pos + 1;
    while (son < len) {
        if (son + 1 < len && arr[son + 1] > arr[son]) {
            ++son;//如果右存在且比左孩子强，son就变成右孩子
        }
        //儿子比爸爸强
        if (arr[son] > arr[father]) {
            SWAP(arr[son], arr[father]);
            father = son;
            son = 2 * father + 1;
        } else {
            //爹的位置坐稳了
            break;
        }
    }
}

void heapSort(int *arr) {
    //从最后一个父亲结点开始做玄武门之变
    //建堆
    for (int i = N / 2 - 1; i >= 0; --i) {
        adjustMaxHeap(arr, i, N);
    }
    //把根和堆底进行交换
    SWAP(arr[0], arr[N - 1]);
    //堆规模从N到N-1
    for (int i = N - 1; i >= 2; --i) {
        adjustMaxHeap(arr, 0, i);
        SWAP(arr[0], arr[i - 1]);
    }
}

void merge(int *arr, int *tmp, int left, int mid, int right) {
    //arr+left得到原数组的首地址，tmp+left得到现数组的首地址
    memcpy(tmp + left, arr + left, (right - left + 1) * sizeof(int));
    //i是第一个数组的头，j是第二个数组的头（一个数组的两个部分）(left,mid)(mid+1,right),k是原数组（已被清空）
    int i, j, k;
    //右边放完了或者左边放完了都是退出条件
    for (i = left, j = mid + 1, k = left; i <= mid && j <= right; ++k) {
        if (tmp[i] < tmp[j]) {
            arr[k] = tmp[i];
            ++i;
        } else {
            arr[k] = tmp[j];
            ++j;
        }
    }
    //左边没放完
    while (i <= mid) {
        arr[k] = tmp[i];
        ++i;
        ++k;
    }
    //右边没放完
    while (j <= right) {
        arr[k] = arr[j];
        ++j;
        ++k;
    }
}

void mergeSort(int *arr, int *tmp, int left, int right) {
    if (left < right) {
        int mid = (left + right) / 2;
        //递归左边
        mergeSort(arr, tmp, left, mid);
        //递归右边
        mergeSort(arr, tmp, mid + 1, right);
        //合并
        merge(arr, tmp, left, mid, right);
    }
}
void countSort(int *arr){
    int count[M] = {0};
    //统计数组
    for (int i = 0; i < N; ++i) {
        ++count[arr[i]];
    }
    //把数据写回到原来的数组
    int k = 0;
    for (int i = 0; i < M; ++i) {
        //访问count[i],i这个元素出现了多少次
        for (int j = 0; j < count[i]; ++j) {
            arr[k] = i;
            k++;
        }
    }
}
void print(int *arr) {
    for (int i = 0; i < N; ++i) {
        printf("%3d", arr[i]);
    }
}
