#ifndef SORT_SORT_H
#define SORT_SORT_H
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#define SWAP(a,b) {int tmp = a;a = b;b = tmp;}
#define N 10
#define M 100
void print(int *arr);
void selectSort(int *arr);
void insertSort(int *arr);
void shellSort(int *arr);
int partition(int *arr,int left,int right);
void quickSort(int *arr,int left,int right);
int compare(const void*lhs,const void*rhs);
void adjustMaxHeap(int *arr,int pos,int len);
void heapSort(int *arr);
void merge(int *arr,int *tmp,int left,int mid,int right);
void mergeSort(int *arr,int *tmp,int left,int right);
void countSort(int *arr);
#endif //SORT_SORT_H
