#ifndef TREE_TREE_H
#define TREE_TREE_H
#include <cstdio>
#include <cstdlib>
#include <cstring>

typedef struct tree{
    char num;
    struct tree *pLeft;
    struct tree *pRight;
}treeNode_t,*pTreeNode_t;


#endif //TREE_TREE_H
