#include "tree.h"

int main() {
    char arr[] = "ABCDEFGHIJ";
    pTreeNode_t pArr[10] = {0};
    for (int i = 0; i < 10; ++i) {
        pArr[i] = (pTreeNode_t) calloc(1, sizeof(treeNode_t));
        pArr[i]->num = arr[i];
    }
    //层次遍历
    pTreeNode_t pRoot = pArr[0];
    for (int i = 0, j = 1; j < 10; ++j) {
        if(pArr[i]->pLeft== nullptr){
            pArr[i]->pLeft = pArr[j];
        }else{
            pArr[i]->pRight = pArr[j];
            ++i;
        }
    }

}
