#include <stdio.h>
#include <setjmp.h>

/*void func(){
    printf("func");
}*/
void a(jmp_buf envbuf);
void b(jmp_buf envbuf);
void a(jmp_buf envbuf){
    printf("before i am a\n");
    b(envbuf);
    printf("after i am a\n");
}

void b(jmp_buf envbuf){
    printf("before i am b\n");
    longjmp(envbuf,1);
    printf("after i am b\n");
}

int f(int n){
    if(n==1){
        return 1;
    } else if(n==2){
        return 2;
    } else{
        return f(n-1)+f(n-2);
    }
}
//a的n词法
int power(int a,int n){
    if(n==0){
        return 1;
    } else if(n%2==0){
        int res = power(a,n/2);
        return res*res;
    } else if(n%2==1){
        int res = power(a,n/2);
        return res*res*a;
    }
}
int main() {
    //函数指针，没有参数没有返回值的函数
    /*void (*p)();
    p = &func;*/
    /*jmp_buf envbuf;
    int ret = setjmp(envbuf);
    if (ret==0){
        a(envbuf);
    }*/
    /*printf("%d",f(4));*/
    printf("%d", power(2,10));
}
