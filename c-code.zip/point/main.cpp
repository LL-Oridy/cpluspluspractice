#include <cstdio>
#include <stdlib.h>

char *printStack(){
    char str[] = "I am printStack";
    puts(str);
    return str;
}
int main(){
    char *p;
    //p = printStack();
    //puts(p);

    char str[] = "hello world";
    char *str1 = "aloha world";

    puts(str);
    puts(str1);

    str[1] = 'H';
    str1[0] = 'A';
    puts(str);
    //puts(str1);

    /*int *arr = (int *)malloc(10* sizeof(int));
    for (int i = 0; i < 10; ++i) {
        arr[i] = i;
    }*/
    /*int arr[] = {2,7,10};
    int *p = arr;
    int j;
    j = *p++;
    printf("j = %d,arr[0] = %d,*p = %d\n",j,arr[0],*p);
    j = p[0]++;
    printf("j = %d,arr[0] = %d,*p = %d\n",j,arr[0],*p);
    j = ++p[0];
    printf("j = %d,arr[0] = %d,*p = %d\n",j,arr[0],*p);*/
}
