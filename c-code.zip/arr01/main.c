#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//[left,right]
int searchInsert(int *nums, int numsSize, int target) {
    int left = 0;
    int right = numsSize - 1;
    while (left <= right) {
        int mid = (left + right) / 2;
        if (target == nums[mid]) {
            return mid;
        } else if (target < nums[mid]) {
            right = mid - 1;

        } else {
            left = mid + 1;
        }
    }
    return right + 1;


}

int getLeftBorder(int *nums, int numsSize, int target);

int getRightBorder(int *nums, int numsSize, int target);

int *searchRange(int *nums, int numsSize, int target, int *returnSize) {
    *returnSize = 2;
    int *ret = (int *) malloc(sizeof(int) * 2);
    int left = getLeftBorder(nums, numsSize, target);
    int right = getRightBorder(nums, numsSize, target);
    if (nums == NULL || left == -2 || right == -2) {
        ret[0] = -1;
        ret[1] = -1;
    } else if (right - left > 1) {
        ret[0] = left + 1;
        ret[1] = right - 1;
    } else {
        ret[0] = -1;
        ret[1] = -1;
    }


    return ret;
}

int getLeftBorder(int *nums, int numsSize, int target) {
    int left = 0;
    int right = numsSize - 1;
    int leftBorder = -2;
    while (left <= right) {
        int mid = (left + right) / 2;
        if (target <= nums[mid]) {
            //包含了target
            right = mid - 1;
            leftBorder = right;
        } else {
            left = mid + 1;
        }
    }
    return leftBorder;
}

int getRightBorder(int *nums, int numsSize, int target) {
    int left = 0;
    int right = numsSize - 1;
    int rightBorder = -2;
    while (left <= right) {
        int mid = (left + right) / 2;
        if (target < nums[mid]) {
            right = mid - 1;

        } else {
            //包含了target
            left = mid + 1;
            rightBorder = left;

        }
    }
    return rightBorder;
}

//int myPow(int x,double n);
int mySqrt(int x) {
    if (x == 1) {
        return 1;
    }
    int left = 0;
    int right = x;
    while (right - left > 1) {
        int mid = (left + right) / 2;
        if (mid > x / mid) {
            right = mid;
        } else {
            left = mid;
        }
    }
    return left;

}

int removeElement(int *nums, int numsSize, int val) {
    int fast;
    int slow = 0;
    for (fast = 0; fast < numsSize; ++fast) {
        if (nums[fast] != val) {
            nums[slow++] = nums[fast];
        }

    }
    return slow;
}

/*int myPow(int x,double n){
    if(n==0){
        return 1;
    }
    double temp = myPow(x,n/2);
    if((int)n%2==0){
        return temp*temp;
    } else{
        return temp*temp*x;
    }
}*/
void reverseString(char *str, int len);

void reverseString(char *str, int len) {
    int i,j;
    //从中间开始找
    for (i = 0, j = len - 1; i < len/2; ++i, --j) {
        char tmp = str[i];
        str[i] = str[j];
        str[j] = tmp;
    }
    printf("%s\n",str);
}



int main() {
    /*int nums[5] = {1, 2, 3, 3, 5};
    int ret = removeElement(nums, 5, 3);
    printf("%d", ret);*/
    /*char str[] = "hello";
    int len = strlen(str);
    reverseString(str,len);*/
}
