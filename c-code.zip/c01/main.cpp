#include <cstdio>

int main() {
    /*int num;
    scanf("%d",&num);
    printf("%d",num);
    char ch;
    rewind(stdin);
    scanf("%c",&ch);
    printf("ch = %c",ch);*/
    //printf("%c\n",'a');
    /*int i;
    int ret;
    while(rewind(stdin),(ret= scanf("%d",&i))!=EOF){
        printf("%d",i);
    }*/

    char ch;
    ch = getchar();
    putchar(ch);
}
