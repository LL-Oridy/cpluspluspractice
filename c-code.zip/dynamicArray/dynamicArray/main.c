#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>


bool isBigMonth(int month) {
	if (month > 0 && month < 13) {
		if (month == 2 || month == 4 || month == 6 || month == 9 || month == 11) {
			return false;
		}
		return true;
	}
	else {
		return false;
	}
}

int atoi(const char* str)
{

}

void sort(int a[], int n) {
	int i = 0, j = 0, tmp = 0;
	for (i = 0; i < n; i++) {
		for (j = i; j < n - 1; j++) {
			if ((a[i] % 2 == 0) && (a[j] % 2 != 0)) {
				tmp = a[j];
				a[j] = a[i];
				a[i] = tmp;
			}
		}
	}
}

int countZero(int N) {
	int count = 0;
	char str[32] = { 0 };

	sprintf(str, "%d", N);
	char* p = str;
	while (*p) {
		printf("s===%c\n", *p);
		if (*p == '0')count++;
		*p++;
	}
	return count;
}

int main() {
	/*int* arr;
	arr = (int*)malloc(10 * sizeof(int));
	for (int i = 0; i < 10; ++i)
	{
		arr[i] = i;
	}
	free(arr);*/

	/*int size;
	scanf("%d", &size);
	char* str = (char*)malloc(size * 1);
	strcpy(str, "hello");
	puts(str);
	str[0] = 'H';
	puts(str);
	free(str);*/


}