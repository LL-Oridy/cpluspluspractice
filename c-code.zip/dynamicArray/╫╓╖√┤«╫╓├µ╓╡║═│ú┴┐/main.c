#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main() {
	char str1[] = "hello world";
	char* str2 = "Aloha world";
	str1[0] = 'H';
	puts(str1);
	str2[0] = 'a';
	puts(str2);
}