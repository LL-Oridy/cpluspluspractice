//#include<iostream>
//using std::cout;
//using std::endl;
#include<cstdio>

//int main() {
//	int value = 300;
//	int value1 = 400;
//	const int* p = &value1;
//	printf("%p\n", p);
//	printf("%d\n", *p);
//	p = &value;
//	printf("%p\n", p);
//	printf("%d\n", *p);
//}
#include <cstdio>


void func(int arr[]) {
    printf("sizeof(arr)=%u\n", sizeof(arr));
    for (int i = 0; i < sizeof(arr) / sizeof(int); ++i) {
        printf("%3d", arr[i]);
    }
}
int main() {
    int arr[8] = { 1,2,3,4,5,6,7,8 };
    for (int i = 0; i < sizeof(arr) / sizeof(int); ++i) {
        printf("%3d", arr[i]);
    }
    printf("\n");
    printf("main sizeof(arr)=%u\n", sizeof(arr));
    func(arr);
}
