#include <cstdio>
#include <string>
#include <map>
#include <algorithm>
using namespace std;

int main() {
    /*int mday[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    string intToWeek[7] = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
    map<string, int> myMap = {
            {"January",   1},
            {"February",  2},
            {"March",     3},
            {"April",     4},
            {"Map",       5},
            {"June",      6},
            {"July",      7},
            {"August",    8},
            {"September", 9},
            {"October",   10},
            {"November",  11},
            {"December",  12}
    };
    int year, mon, day;
    char str[100];
    string month;
    bool isBefore;
    while (scanf("%d%s%d", &day, str, &year) != EOF) {
        month = str;//c风格转c++
        mon = myMap[month];
        if (year < 2022 || 2022 == year && mon < 11 || 2022 == year && 11 == mon && day < 19) {
            isBefore = true;
        } else {
            isBefore = false;
        }
        //从begin走到end
        int begYear, begMon, begDay, endYear, endMon, endDay;
        if (isBefore) {
            begYear = year;
            begMon = mon;
            begDay = day;
            endYear = 2022;
            endMon = 11;
            endDay = 19;
        } else {
            begYear = 2022;
            begMon = 11;
            begDay = 19;
            endYear = year;
            endMon = mon;
            endDay = day;
        }
        int totalDay = 0;
        while (true) {
            if (begYear == endYear && begMon == endMon && begDay == endDay) {
                break;
            }
            ++totalDay;
            bool isLeap = begYear % 400 == 0 || begYear % 4 == 0 && begYear % 100 != 0;
            if (isLeap) {
                mday[2] = 29;
            } else {
                mday[2] = 28;
            }
            ++begDay;
            if (begDay > mday[begMon]) {
                begDay = 1;
                ++begMon;
                if (begMon > 12) {
                    begMon = 1;
                    ++begYear;
                }
            }

        }
        if (isBefore) {
            printf("%s\n", intToWeek[(11 - totalDay % 7) % 7].c_str());

        } else {
            printf("%s\n", intToWeek[(totalDay + 4) % 7].c_str());
        }

    }*/
    /*map<string,string> myMap = {
            {"zhangsan","zs"},
            {"lisi","ls"}
    };
    char str[100];
    gets(str);
    string name = str;
    printf("%s的名字缩写是%s\n",name.c_str(),myMap[name].c_str());*/

    /*int tree[10240];
    int L,M;
    scanf("%d%d",&L,&M);
    for (int i = 0; i < L+1; ++i) {
        tree[i] = 1;
    }
    for (int idx = 0; idx < M; ++idx) {
        int left,right;
        scanf("%d%d",&left,&right);
        for (int i = left; i <= right; ++i) {
            tree[i] = 0;
        }
    }
    int totalNum = 0;
    for (int i = 0; i <= L; ++i) {
        if (1==tree[i]){
            ++totalNum;
        }
    }
    printf("%d\n",totalNum);*/

    /*map<char, int> inputTime = {
            {'a', 1},
            {'b', 2},
            {'c', 3},
            {'d', 1},
            {'e', 2},
            {'f', 3},
            {'g', 1},
            {'h', 2},
            {'i', 3},
            {'m', 1},
            {'n', 2},
            {'o', 3},
            {'p', 1},
            {'q', 2},
            {'r', 3},
            {'s', 4},
            {'t', 1},
            {'u', 2},
            {'v', 3},
            {'w', 1},
            {'x', 2},
            {'y', 3},
            {'z', 4}
    };
    //某个字母属于哪个按键
    map<char, int> keyMap = {
            {'a', 2},
            {'b', 2},
            {'c', 2},
            {'d', 3},
            {'e', 3},
            {'f', 3},
            {'g', 4},
            {'h', 4},
            {'i', 4},
            {'j', 5},
            {'k', 5},
            {'l', 5},
            {'m', 6},
            {'n', 6},
            {'o', 6},
            {'p', 7},
            {'q', 7},
            {'r', 7},
            {'s', 7},
            {'t', 8},
            {'u', 8},
            {'v', 8},
            {'w', 9},
            {'x', 9},
            {'y', 9},
            {'z', 9}
    };
    char str[101];
    while (scanf("%s", str) != EOF) {
        int lastInput = 1;//初始的时候
        int totalTime = 0;
        for (int i = 0; str[i] != '\0'; ++i) {
            //判断是否需要等待
            if (lastInput == keyMap[str[i]]) {
                totalTime += 2;
            }
            totalTime = totalTime+inputTime[str[i]];//输入本字母所需要的时间
            lastInput = keyMap[str[i]];//记录本次按下的数字
        }
        printf("%d\n",totalTime);
    }
*/

    int n;
    int arr[101];
    scanf("%d",&n);
    for (int i = 0; i < n; ++i) {
        scanf("%d",&arr[i]);
    }
    //start,end ->end:尾后，最后一个元素后面一个的地址
    sort(arr,arr+n);
    for (int i = 0; i < n; ++i) {
        printf("%d",arr[i]);
    }
    printf("\n");

}
