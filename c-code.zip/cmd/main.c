#include <stdio.h>
#include <string.h>
int main(int argc,char *argv[]) {
    /*printf("argc = %d\n",argc);
    for (int i = 0; i < argc; ++i) {
        puts(argv[i]);
    }*/
    FILE *fp = fopen("F:\\c-code\\file\\1.txt","r+");
    if(fp==NULL){
        perror("fopen");
    }
    /*char str[20] = "helloworld";
    fwrite(str,1, strlen(str),fp);*/

    char str1[20] = {0};
    fread(str1,1, sizeof(str1)-1,fp);
    puts(str1);
    fclose(fp);
    return 0;
}
