#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void printArr(char (*p)[10], int row) {
    for (int i = 0; i < row; ++i) {
        puts(p[i]);
    }
}

void printPoint(char **pArr,int row){
    for (int i = 0; i < 5; ++i) {
        puts(pArr[i]);
    }
}
int main() {
    /*int arr[3][4] = {1,2,3,4,5,6,7,8,9,10,11,12};
    int (*p)[4];
    p = arr;*/

    /*int row;
    scanf("%d",row);
    int (*arr)[5] = (int (*)[5])malloc(row*5* sizeof(int));
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < 5; ++j) {
            arr[i][j] = 0;
        }
    }*/

    char str[5][10] = {
            "zhangsan",
            "lisi",
            "hello",
            "liqiang",
            "world"
    };
    //printArr(str,5);

    /*for (int i = 5; i >= 2; i--) {
        for (int j = 0; j < i - 1; ++j) {
            if (strcmp(str[j], str[j + 1]) > 0) {
                char tmp[10];
                strcpy(tmp, str[j]);
                strcpy(str[j], str[j + 1]);
                strcpy(str[j + 1], tmp);
            }

        }
    }
    printf("----------------------------------------------\n");
    printArr(str,5);
*/
    char *pArr[5];
    for (int i = 0; i < 5; ++i) {
        pArr[i] = &str[i][0];
    }
    for (int i = 0; i < 5; ++i) {
        puts(pArr[i]);
    }
    for (int i = 5; i >= 2; --i) {
        for (int j = 0; j < i - 1; ++j) {
            if (strcmp(pArr[j], pArr[j + 1]) > 0) {
                //
                char *pTmp = pArr[j];
                pArr[j] = pArr[j + 1];
                pArr[j + 1] = pTmp;

            }
        }
    }
    printf("----------------\n");
    for (int i = 0; i < 5; ++i) {
        puts(pArr[i]);
    }
}
