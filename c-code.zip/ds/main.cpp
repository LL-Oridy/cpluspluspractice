#include <cstdio>
#include <cstdlib>

typedef struct node_s {
    int num;
    struct node_s *pNext;
} node_t, *pNode_t;

void sortInsert(pNode_t *ppHead, pNode_t *ppTail, int num) {
    pNode_t pNew = (pNode_t) calloc(1, sizeof(node_t));
    pNew->num = num;
    if (*ppHead == nullptr) {
        *ppHead = pNew;
        *ppTail = pNew;
    } else if (num < (*ppHead)->num) {
        pNew->pNext = *ppHead;
        *ppHead = pNew;
    } else {
        //pPre查找修改指针域的节点，pCur是pPre的后继节点
        pNode_t pPre = *ppHead;
        pNode_t pCur = pPre->pNext;
        while (pCur) {
            if (pCur->num > num) {
                pPre->pNext = pNew;
                pNew->pNext = pCur;
                break;
            }
            pPre = pCur;
            pCur = pCur->pNext;
        }
        if (pCur == nullptr) {
            (*ppTail)->pNext = pNew;
            *ppTail = pNew;
        }
    }
}
void printList(pNode_t pHead){
    while (pHead){
        printf("%d",pHead->num);
        pHead = pHead->pNext;
    }
}

int main() {
    pNode_t pHead = NULL;
    pNode_t pTail = NULL;
    int num;
    while (scanf("%d", &num) != EOF) {
        sortInsert(&pHead, &pTail, num);

    }
    printList(pHead);

}
