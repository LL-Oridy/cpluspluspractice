#include <cstdio>
#include <map>
using namespace std;

int main(){
    map<int,int> findIndex;
    int m,n;
    int arr[101];
    while (scanf("%d",&n)!=EOF){
        for (int i = 0; i < n; ++i) {
            scanf("%d",&arr[i]);
            findIndex[arr[i]] = i;//数组元素作为键，数组元素下标作为值
        }

    }
}
