#include <cstdio>


void func(int arr[]){
    printf("sizeof(arr)=%u\n", sizeof(arr));
    for (int i = 0; i < sizeof(arr) / sizeof(int); ++i) {
        printf("%3d",arr[i]);
    }
}
int main(){
    /*int i = 1;
    int count = 0;
    label:
        count = count+i;
        ++i;
        if(i<=100){
            goto label;
        }
    printf("%d",count);*/
    int arr[8] = {1,2,3,4,5,6,7,8};
    for (int i = 0; i < sizeof(arr) / sizeof(int); ++i) {
        printf("%3d",arr[i]);
    }
    printf("\n");
    /*for (int i = 0; i < SIZE; ++i) {
        arr[i] = i;
    }*/
    printf("main sizeof(arr)=%u\n", sizeof(arr));
    func(arr);
}
