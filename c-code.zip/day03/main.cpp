#include <cstdio>
#include <string>
#include <cstdlib>

int main() {
    /*int n;//外框长度
    char inner, outter; //inner:内花色，outter：外花色
    bool flag = true;//是否是第一行结果
    while (scanf("%d %c %c", &n, &inner, &outter) != EOF) {
        //处理空行的显示
        if (flag == true) {
            flag = false;
        } else {
            printf("\n");
        }
        //二维数组长度固定
        char pattern[80][80] = {0};
        int len = 1;//框的长度
        int x, y;//起点的下标
        char curChar = inner;//花色
        for (len = 1, x = n / 2, y = n / 2; len <= n; len = len + 2, --x, --y) {
            //从左到右
            for (int i = x, j = y; i < x + len; ++i) {
                //j不变，i从x到x+len-1
                pattern[i][j] = curChar;
            }
            for (int i = x, j = y; j < y + len; ++j) {
                pattern[i][j] = curChar;
            }
            for (int i = x + len - 1, j = y; j < y + len; ++j) {
                pattern[i][j] = curChar;
            }
            for (int i = x, j = y + len - 1; i < x + len; ++i) {
                pattern[i][j] = curChar;
            }
            //更换花色
            if (curChar == inner) {
                curChar = outter;
            } else {
                curChar = inner;
            }
        }
        //磨掉四个角
        if (n != 1) {
            pattern[0][0] = ' ';
            pattern[0][n - 1] = ' ';
            pattern[n - 1][0] = ' ';
            pattern[n - 1][n - 1] = ' ';
        }
        for (int i = 0; i < n; ++i) {
            printf("%s\n", pattern[i]);
        }
    }*/
    /*int year, mon, day;
    int mday[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 12};
    int totalDay[13] = {0};
    for (mon = 2; mon <= 12; mon++) {
        //到mon月1日的天数=到mon-1月1日的天数+第mon-1月的天数
        totalDay[mon] = totalDay[mon - 1] + mday[mon - 1];
    }
    while (scanf("%d%d%d", &year, &mon, &day) != EOF) {
        bool isLeap = year % 400 == 0 || year % 100 != 0 && year % 4 == 0;
        if (isLeap == true && mon >= 3) {
            printf("%d\n", totalDay[mon] + day + 1);
        } else {
            printf("%d\n", totalDay[mon] + day);
        }
    }*/
    /*int year, n;
    int mday[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 12};
    while (scanf("%d%d", &year, &n) != EOF) {
        int mon = 1;
        int day = 1;
        for (int i = 0; i < n-1; ++i) {
            //nextDay 万能方案
            bool isLeap = year%400==0||year%100!=0&&year%4==0;
            if(isLeap){
                mday[2] = 29;
            } else{
                mday[2] = 28;
            }
            ++day;
            if (day > mday[mon]) {
                ++mon;
                day = 1;
                if (mon > 12) {
                    mon = 1;
                    ++year;
                }
            }
        }
        printf("%04d-%02d-%02d\n",year,mon,day);
    }*/


}