#include <cstdio>
int reverse(int n){
    int rev = 0; //4321
    int remain = 0; //1,2,3,4
    while (true) {
        remain = n % 10;
        n = n / 10;
        rev = rev * 10 + remain;
        if (n == 0) {
            break;
        }
    }
    return rev;
}
int main() {
    /*int a, b, c;
    for (a = 0; a <= 5; ++a) {
        for (b = 0; b <= 5; ++b) {
            for (c = 0; c <= 9; ++c) {
                if ((a * 100 + b * 10 + c) + (100 * b + 10 * c + c) == 532) {
                    printf("%d %d %d\n", a, b, c);
                }
            }
        }
    }*/
    int a, b, c, d;
    for (a = 1; a <= 9; ++a) {
        for (b = 0; b <= 9; ++b) {
            //...
            for (c = 0; c <= 9; ++c) {
                for (d = 0; d <= 9; ++d) {
                    int n = 1000*a+100*b+10*c+d;
                    int rev = reverse(n);
                    if(n*9==rev){
                        printf("%d",rev);
                    }
                }
            }
        }
    }
    /*while (n > 0) { //找到最后一次循环确定循环的边界
        remain = n % 10;
        n = n / 10;
        rev = rev * 10 + remain;
    }*/

}
