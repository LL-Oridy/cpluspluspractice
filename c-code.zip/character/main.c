#include <stdio.h>
#include <string.h>
void myPuts(char str[]) {
    //如果str[i]为0为结束符，就结束循环
    for (int i = 0; str[i]; ++i) {
        printf("%c",str[i]);
    }
    printf("\n");
}

size_t myStrlen(char str[]){
    size_t length = 0;
    for (int i = 0; str[i]; ++i) {
        ++length;
    }
    return length;
}
int main() {
    // char str[] = "hello";
    // myPuts(str);

    char buf[1024];
    /*scanf("%s",buf);
    puts(buf);*/
    //gets(buf);
    fgets(buf,sizeof(buf),stdin);
    int len = myStrlen(buf);
    if(buf[len-1]=='\n'){
        buf[len-1] = 0;
    }
    char str1[1024];
    strcpy(str1,buf);
    puts(str1);

}