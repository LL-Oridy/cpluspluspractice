#include <cstdio>

struct student_s{
    int num;
    char name[20];
    int age;
};
int main(){
    /*struct student_s student = {
            1001,
            "zhangsan",
            21
    };*/
    //printf("%s",student.name);
    struct student_s arr[3] = {
            1001,"zhangsan",21,
            1003,"lisi",22,
            1005,"wangwu",23
    };

    struct student_s *p = arr;
    int num;
    num = p->num;
    num = p->num++;
    printf("%d%d\n",num,p->num);
}
