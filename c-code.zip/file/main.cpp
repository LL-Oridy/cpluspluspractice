#include <cstdio>
#include <cstdlib>
#include <cstring>

int main() {
    FILE *fp = fopen("F:\\c-code\\file\\1.txt", "r+");
    if (fp == nullptr) {
        perror("text");
        return -1;
    }
    //printf("success errno = %d",errno);
    /*char ch  = 'H';
    int ret = fputc(ch,fp);
    while (ret==-1){
        perror("fputc");
        return -1;
    }*/
    /*while ((ch = fgetc(fp))!=EOF){
        printf("%c",ch);
    }
    printf("\n");*/
    char ch;
    while ((ch = fgetc(fp))!=EOF){
        if(ch<='z'&&ch>='a'){
            ch = ch-32;
            //先挪指针
            fseek(fp,-1,SEEK_CUR);
            fputc(ch,fp);
        }
        fseek(fp,0,SEEK_CUR);
    }

    fclose(fp);

    return 0;
}
