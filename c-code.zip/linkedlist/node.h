#ifndef LINKEDLIST_NODE_H
#define LINKEDLIST_NODE_H
#include <cstdio>
#include <cstdlib>
#include <cstring>

typedef struct node{
    int num;
    struct node *pNext;
}node_t,*pNode_t;

void headInsert(pNode_t *ppHead,pNode_t *ppTail,int num);
void tailInsert(pNode_t *ppHead,pNode_t *ppTail,int num);
void sortInsert(pNode_t *ppHead,pNode_t *ppTail,int num);
void printList(pNode_t pHead);
int compare(const void*lhs,const void*rhs);
#endif //LINKEDLIST_NODE_H
