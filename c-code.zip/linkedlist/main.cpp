#include "node.h"


int main() {
    pNode_t pHead = nullptr;
    pNode_t pTail = nullptr;
    int num;
    while (scanf("%d", &num) != EOF) {
        tailInsert(&pHead, &pTail, num);
    }
    pNode_t arr[6] = {0};
    pNode_t pCur = pHead;
    for (int i = 0; i < 6; ++i) {
        arr[i] = pCur;
        pCur = pCur->pNext;
    }
    qsort(arr,6, compare);
    //printList(pHead);
}



int compare(const void*lhs,const void*rhs){

}
void headInsert(pNode_t *ppHead, pNode_t *ppTail, int num) {
    pNode_t pNew = (pNode_t) calloc(1, sizeof(node_t));
    pNew->num = num;
    if (*ppHead == nullptr) {
        *ppHead = pNew;
        *ppTail = pNew;
    } else {
        pNew->pNext = *ppHead;
        *ppHead = pNew;
    }
}

void tailInsert(pNode_t *ppHead, pNode_t *ppTail, int num) {
    pNode_t pNew = (pNode_t) calloc(1, sizeof(node_t));
    pNew->num = num;
    if (*ppHead == nullptr) {
        *ppHead = pNew;
        *ppTail = pNew;
    } else {
        (*ppTail)->pNext = pNew;
        *ppTail = pNew;
    }
}

void sortInsert(pNode_t *ppHead, pNode_t *ppTail, int num) {
    pNode_t pNew = (pNode_t) calloc(1, sizeof(node_t));
    pNew->num = num;
    if (*ppHead == nullptr) {
        *ppHead = pNew;
        *ppTail = pNew;
    }
    else if ((*ppHead)->num > pNew->num) {
        pNew->pNext = *ppHead;
        *ppHead = pNew;
    } else{
        pNode_t pPre = *ppHead;
        pNode_t pCur = pPre->pNext;
        while (pCur){
            if (pNew->num < pPre->num) {
                pPre->pNext = pNew;
                pNew->pNext = pCur;
                break;
            }
            pPre = pCur;
            pCur = pCur->pNext;
        }
        //插入的是最后一个
        if(pCur== nullptr){
            (*ppTail)->pNext = pNew;
            *ppTail = pNew;
        }

    }

}

void printList(pNode_t pHead) {
    pNode_t pCur = pHead;
    while (pCur != nullptr) {
        printf("%d ", pCur->num);
        pCur = pCur->pNext;
    }
    printf("\n");
}