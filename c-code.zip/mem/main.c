#include <stdio.h>
#include <string.h>
int main() {
    /*int arr1[] = {1,2,3,4,5};
    int arr2[5];*/

    //memcpy(arr2,arr1, sizeof(arr1));
    //memset(arr1,0, sizeof(arr1));
    //char str[10];
    int i = 1234;
    //sscanf(str,"%d",&i);

    //sprintf(str,"%x\n",i);
    //printf("%s",str);

    int *p = &i;
    printf("sizeof(p)=%u\n", sizeof(p));
    printf("*p=%d", *p);

}
