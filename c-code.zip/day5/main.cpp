#include <iostream>
#include <algorithm>
#include <map>

using namespace std;

/*bool compare(int lhs,int rhs){
    if(lhs>rhs){
        return true;
    } else{
        return false;
    }
}
int main() {
    int arr[8];
    for (int i = 0; i < 8; ++i) {
        scanf("%d",&arr[i]);
    }
    sort(arr,arr+8, compare);
}*/
/*bool compare(int lhs, int rhs) {
    if (lhs % 2 == 1 && rhs % 2 == 0) {
        return true;
    } else if (lhs % 2 == 1 && rhs % 2 == 1 && lhs > rhs) {
        return true;
    } else if (lhs % 2 == 0 && rhs % 2 == 0 && rhs > lhs) {
        return true;
    } else{
        return false;
    }
}

int main() {
    int arr[10];
    while (scanf("%d%d%d%d%d%d%d%d%d%d", arr, arr + 1, arr + 2, arr + 3, arr + 4, arr + 5, arr + 6, arr + 7, arr + 8,
                 arr + 9) != EOF) {
        sort(arr, arr + 10, compare);
    }
}*/
/*struct Student {
    int num;
    int grade;
};*/
/*
bool compare(Student lhs, Student rhs) {
    if (lhs.grade < rhs.grade) {
        return true;
    } else if (lhs.grade == rhs.grade && lhs.num < rhs.num) {
        return true;
    } else {
        return false;
    }
}

int main() {
    Student arr[101];
    int n;
    scanf("%d", &n);
    for (int i = 0; i < n; ++i) {
        scanf("%d%d", &arr[i].num, &arr[i].grade);
    }
    sort(arr, arr + n, compare);
}*/
/*
struct Student{
    char name[50];
    int grade;
    int seq;//记录录入顺序
};
bool comp0(Student lhs,Student rhs){
    if(lhs.grade<rhs.grade){
        return true;
    } else if(lhs.grade==rhs.grade&&lhs.seq<rhs.seq){
        return true;
    }
    else{
        return false;
    }
}
bool comp1(Student lhs,Student rhs){
    if(lhs.grade>rhs.grade){
        return true;
    } else if(lhs.grade==rhs.grade&&lhs.seq<rhs.seq){
        return true;
    }
    else{
        return false;
    }
}

int main(){
    int N;
    int order;
    Student arr[100];
    while (scanf("%d%d",&N,&order)!=EOF){
        int seq = 0;
        for (int i = 0; i < N; ++i) {
            scanf("%s%d",arr[i].name,&arr[i].grade);
            arr[i].seq = seq;
            ++seq;
        }
    }
    if(0==order){
        sort(arr,arr+N, comp0);
    } else{
        sort(arr,arr+N, comp1);
    }
}*/
int arr[100];
bool binarySearch(int n,int x){
    int left = 0;
    int right = n-1;
    while (right>=left){
        int mid = (left+right)/2;
        if(arr[mid]==x){
            return true;
        }else if(arr[mid]>x){
            right = mid-1;
        } else{
            left = mid+1;
        }
    }
    return false;
}
int main(){
    int n,m;
    while (scanf("%d",&n)!=EOF){
        for (int i = 0; i < n; ++i) {
            scanf("%d",&arr[i]);
        }

    }
    sort(arr,arr+n);
    scanf("%d",&m);
    for (int i = 0; i < m; ++i) {
        int x;
        scanf("%d",&x);
    }
    if(binarySearch(n,m)){
        printf("Yes\n");
    } else{
        printf("No\n");
    }
}