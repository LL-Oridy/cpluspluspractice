#include <cstdio>

/*int rev(int n){
    int rev = 0;
    //每次的余数
    int remain = 0;
    while (true){
        remain = n%10;
        n = n/10;
        rev = rev*10+remain;
        if(n==0){
            break;
        }
    }
}*/

//二维数组(全局)
char arr[1000][3000];
int main(){
    //int i;
    /*for (i = 0; i <= 256; ++i) {
        if(i*i== rev(i*i)){
            printf("%d\n",i);
        }
    }*/
    int h;
    while (scanf("%d",&h)!=EOF){
        //全填空格
        for (int i = 0; i < h; ++i) {
            for (int j = 0; j < 3*h-2; ++j) {
                arr[i][j] = ' ';
            }
            //用来指示每一行字符串的结束
            arr[i][3*h-2] = '\0';
        }
        //从最后一行开始填充
        int beg = 0;
        for (int i = h-1; i >= 0; --i) {
            //从最左边开始填充
            for (int j = beg; j < 3*h-2; ++j) {
                arr[i][j] = '*';
            }
            beg = beg+2;
        }

        for (int i = 0; i < h; ++i) {
            /*for (int j = 0; j < 3*h-2; ++j) {
                printf("%c",arr[i][j]);
            }*/
            //读取一整行字符串
            printf("%s\n",arr[i]);
        }

    }
    return 0;
}